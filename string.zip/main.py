'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
# n = input("enter a number")
# p= int(input("enter a number"))

# c=n+p
# print(c)

s="helloworld"

print(s[4])
print(len(s))
print(s[1 : 4])
s=s.capitalize()# only 0 index are string
print(s)
s= s.upper()
print(s)
s=s.title()
print(s)
print(s.find('x'))
print(s.count('l'))
print(s.replace('e','o'))
print(s.isalpha())
print(s.isdigit())
print(s.isalnum())
print(s.startswith('He'))
print(s.endswith('dl'))   

