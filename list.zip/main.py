'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
list = [1,2,3,4,4,4,4,5]

# len(list)
# s="hello"
# print(type(s))
# print(type(list))
# print(len(list))
# print(list[2])
# list[1]=4
# print(list)
# a=list[1 : 4]
# print(a)
# list.append(5)
# print(list)
# list.insert(2,8)
# print(list)
# list.remove(4)
# print(list)
# list.pop(1)
# print(list)
# list.sort()
# print(list)
# list.sort(reverse=True)#decendimg
# print(list)

list =[1,2,3,4]
list2=[2,3,4,5]
# result = list+list2
# print(result)

list.extend(list2)
print(list)

list2= list.copy()
print(list2)

list.clear()
print(list)
del list
print(list)

a=list((1,2,3))
print(a)

# for i in a:
#   print(i)

# a.count(3)
# print(a.count(2))

# list = ['a','d','s','e','q','r','s','s']

# count=0
# for i in list:
#     if i=='s':
#      count+=1
# print(count)    

list = [1,5,7,9,10]

  
# max=0
  
# for i in list:
#     if i>max:
#       max=i
    
# print(max)

# min=list[0]

# for i in list:
#   if i<min:
#       min=i
# print(min)   

# a= max(list)


# print(a)

# t=(1,2,3,4)

# print(type(t))
# len(t)
# print(len(t))

# t=(1,)
# print(type(t))

# a= tuple((1,2,3,4))
# print(a) 

a=tuple((1,2,3,4))
l=list(a)
print(l)