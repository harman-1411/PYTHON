'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
# tuple = ("Harman",862,"blue")
# name,rollno,color=tuple
 
# print(name)
# print(rollno)
# print(color)
 
# t1=(1,2,3,4)
# list=list(t1)

# list.sort(reverse=True)
# t=tuple(list
# print(t)
 
# number=[1,2,3,4]
# reversed_number= number[::-1]

# print(reversed_number)
 

# list=[1,2,3,4]
# rev=[]

# for i in range(len(list)-1,-1,-1):
    
#     rev.append(list[i])
    
    
# print(rev)    
    
    
    
# ")list=[1,2,3,4]

# max=list[0]
# max2=list[0]
# for i in range(len(list)):
#   if list[0]>max:
#       continue
#   elif list[0]>max2:
#       print(max2)
#       break

#   else:
#       print("not found        


# list = [1, 2, 3, 4]

# largest = max(list)
# second = list[0]

# for i in list:
#     if i != largest and i > second:
#         second = i

# print("2nd largest =", second)

# list = [1, 2, 3, 4]

# largest = second = -1

# for i in list:
#     if i > largest:
#         second = largest
#         largest = i
#     elif i > second:
#         second = i

# print("2nd largest =", second)